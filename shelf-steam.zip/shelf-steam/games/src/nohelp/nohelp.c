#include <stdio.h>

int main() {
    return 0;  // Exits without printing anything
}
