// Dung Tien Do 
// U20764476

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <ctype.h>

#define MAX_INPUT_SIZE 256
#define ERROR_MESSAGE "An error has occurred\n"

// Global variable to store the current game directory path
char *game_path = NULL;

// Function to print an error message to stderr
void print_error() {
    write(STDERR_FILENO, ERROR_MESSAGE, strlen(ERROR_MESSAGE));
    fflush(stderr);
}

// Function to check if a given path is a valid directory
int is_directory(const char *path) {
    struct stat path_stat;
    return (stat(path, &path_stat) == 0 && S_ISDIR(path_stat.st_mode));
}

// Function to remove leading and trailing whitespace from a string
char* remove_space(char *str) {
    if (str == NULL) return NULL;

    // Remove leading whitespace
    while (isspace((unsigned char)*str)) {
        str++;
    }
    // Remove trailing whitespace
    char *end = str + strlen(str) - 1;
    while (end > str && isspace((unsigned char)*end)) {
        *end = '\0';
        end--;
    }
    return str;
}

// Function to get the help description of a game by executing its help command
char* get_description(const char *game_dir, const char *filename) {
    static char description[1024];
    description[0] = '\0';

    // Construct the full path to the game executable
    char fullpath[1024];
    snprintf(fullpath, sizeof(fullpath), "%s/%s", game_dir, filename);

    // Create a temporary file to capture the output
    char tmpfile[] = "/tmp/files_XXXXXX";
    int fd = mkstemp(tmpfile);
    if (fd < 0) {
        strcpy(description, "(empty)");
        return description;
    }
    close(fd);

    // Fork a child process to run the help command
    pid_t pid = fork();
    if (pid < 0) {
        print_error();
        strcpy(description, "(empty)");
        unlink(tmpfile);
        return description;
    } else if (pid == 0) {
        // Child process: redirect stdout to the temporary file
        int out = open(tmpfile, O_WRONLY | O_TRUNC, 0666);
        if (out < 0) _exit(1);
        dup2(out, STDOUT_FILENO);
        close(out);

        // Execute the help command
        char *args[3] = {(char *)filename, "--help", NULL};
        execvp(fullpath, args);
        _exit(1); // If execvp fails
    } else {
        // Parent process: wait for the child to finish
        waitpid(pid, NULL, 0);

        // Read the help description from the temporary file
        FILE *fp = fopen(tmpfile, "r");
        if (fp == NULL) {
            strcpy(description, "(empty)");
        } else {
            size_t bytes = fread(description, 1, sizeof(description) - 1, fp);
            description[bytes] = '\0';
            fclose(fp);
            // Trim whitespace from the description
            char *desc_trim = remove_space(description);
            if (desc_trim[0] == '\0') {
                strcpy(description, "(empty)");
            } else {
                memmove(description, desc_trim, strlen(desc_trim) + 1);
            }
        }
        unlink(tmpfile); // Remove the temporary file
    }
    return description;
}

// Function to list available games in the current game directory
void list_games() {
    DIR *dir = opendir(game_path);
    if (!dir) {
        print_error();
        return;
    }

    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        // Skip current and parent directory entries
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
            continue;
        }
        // Get the help description for the game
        char *help = get_description(game_path, entry->d_name);
        printf("%s: %s\n", entry->d_name, help);
    }
    closedir(dir);
}

// Function to execute a game with optional input redirection
void execute_game(char *command) {
    char *args[MAX_INPUT_SIZE / 2 + 1]; // Array to hold command arguments
    char *input_file = NULL;
    int input_redirection = 0;
    char *token;
    int i = 0;

    // Tokenize the command input
    token = strtok(command, " ");
    while (token != NULL) {
        if (strcmp(token, "<") == 0) {
            if (input_redirection) { // More than one '<' is an error
                print_error();
                return;
            }
            input_redirection = 1;
            token = strtok(NULL, " ");
            if (token == NULL) { // No file specified
                print_error();
                return;
            }
            input_file = token; // Store the input file name
            token = strtok(NULL, " "); // Check for extra arguments
            if (token != NULL) { // Extra arguments after redirection is an error
                print_error();
                return;
            }
        } else {
            args[i++] = token; // Store the command argument
        }
        token = strtok(NULL, " ");
    }
    args[i] = NULL; // Null-terminate the argument list

    // Check if the command is empty
    if (i == 0) {
        print_error();
        return;
    }

    // Validate input file before forking
    if (input_redirection) {
        int fd = open(input_file, O_RDONLY);
        if (fd < 0) { // If file doesn't exist or can't be opened
            print_error();
            return;
        }
        close(fd);
    }

    // Handle built-in commands
    if (strcmp(args[0], "exit") == 0) {
        if (i > 1) {
            print_error();
            return;
        }
        exit(0);
    } else if (strcmp(args[0], "ls") == 0) {
        list_games();
        return;
    } else if (strcmp(args[0], "path") == 0) {
        if (i != 2) {
            print_error();
            return;
        }
        // Change the game directory path
        if (is_directory(args[1])) {
            free(game_path);
            game_path = strdup(args[1]);
        } else {
            print_error();
        }
        return;
    }

    // Construct the full path to the game executable
    char game_command[MAX_INPUT_SIZE];
    snprintf(game_command, sizeof(game_command), "%s/%s", game_path, args[0]);

    // Fork a child process to execute the game
    pid_t pid = fork();
    if (pid < 0) { // Fork failed
        print_error();
        return;
    } else if (pid == 0) { // Child process
        if (input_redirection) {
            int fd = open(input_file, O_RDONLY);
            if (fd < 0) {
                print_error();
                exit(1);
            }
            dup2(fd, STDIN_FILENO); // Redirect stdin
            close(fd);
        }

        execvp(game_command, args); // Execute the game
        print_error(); // If execvp fails
        exit(1);
    } else { // Parent process
        int status;
        waitpid(pid, &status, 0); // Wait for the child process to finish
    }
}

// Main function to run the shell
int main(int argc, char *argv[]) {
    // Check for correct usage
    if (argc != 2) {
        print_error();
        exit(1);
    }

    // Validate the provided directory
    if (!is_directory(argv[1])) {
        print_error();
        exit(1);
    }

    game_path = strdup(argv[1]); // Store the game directory path
    char input[MAX_INPUT_SIZE];

    // Main loop to read and execute commands
    while (1) {
        printf("shelf-steam> ");
        fflush(stdout);

        if (fgets(input, sizeof(input), stdin) == NULL) {
            break; // EOF
        }

        // Remove trailing newline
        input[strcspn(input, "\n")] = 0;

        // Ignore empty input
        if (strlen(input) == 0) {
            continue;
        }

        execute_game(input); // Execute the command
    }

    free(game_path); // Free allocated memory
    return 0;
}